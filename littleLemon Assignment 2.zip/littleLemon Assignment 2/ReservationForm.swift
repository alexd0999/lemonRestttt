//
//  ReservationForm.swift
//  littleLemon Assignment 2
//
//  Created by Alex Arthur on 10/24/25.
//

import SwiftUI

struct ReservationForm: View {
    
    @State private var name: String = ""
    @State private var guestCount: Int = 1

    var body: some View {
        NavigationView {
            
            Form {
                
                Section(header: Text("Reservation Details")) {
                    
                    TextField("Someone", text: $name)
                    
                    Stepper("Guests: \(guestCount)", value: $guestCount, in: 1...10)
                }
                
                Section(header: Text("Reservation Summary")) {
                    Text("Name: \(name)")
                    Text("Guests: \(guestCount)")
                }
            }
            .navigationTitle("Reservation")
        }
    }
}

struct ReservationForm_Previews: PreviewProvider {
    static var previews: some View {
        ReservationForm()
    }
}
