//
//  littleLemon_Assignment_2App.swift
//  littleLemon Assignment 2
//
//  Created by Alex Arthur on 10/24/25.
//

import SwiftUI

@main
struct littleLemon_Assignment_2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
