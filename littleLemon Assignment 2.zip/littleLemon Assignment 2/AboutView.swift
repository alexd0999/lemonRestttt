//
//  AboutView.swift
//  littleLemon Assignment 2
//
//  Created by Alex Arthur on 10/24/25.
//


import SwiftUI

struct AboutView: View {
    var body: some View {
        VStack {
            Text("Welcome to Little Lemon!")
                .font(.title)
                .padding()
            Image("littleLemon")
                .resizable()
                .scaledToFit()
                .frame(height: 200)
        }
    }
}
