//
//  ContentView 2.swift
//  littleLemon Assignment 2
//
//  Created by Alex Arthur on 10/24/25.
//


import SwiftUI

struct ContentView: View {
    var body: some View {
            ReservationForm()
            
        }
    }
