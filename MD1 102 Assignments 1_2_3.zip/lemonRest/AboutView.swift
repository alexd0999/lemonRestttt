import SwiftUI

struct AboutView: View {
    var body: some View {
        // Removed NavigationStack
        VStack {
            Text("Welcome to Little Lemon!")
                .font(.title)
                .padding()
            
            Spacer()
        }
        .navigationTitle("About Us") // This modifier now applies to MainView's stack
    }
}

#Preview {
    AboutView()
}
