//
//  MainView.swift
//  lemonRest
//
//  Created by Alex Arthur on 10/23/25.
//

import SwiftUI

struct MainView: View {
    @State private var uName = ""
    @State private var isLoggedIn = true
    
    // For Assignment 2: State to show the dessert sheet
    @State private var showDesserts = false

    var body: some View {
        // Modernized to NavigationStack
        NavigationStack {
            if isLoggedIn == true {
                VStack(spacing: 20) {
                    Text("Welcome \(uName)")
                        .font(.title)
                        .bold()
                    
                    Image("littleLemon")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 200)
                    
                    NavigationLink("Make a reservation",
                       destination:ReservationForm())
                    
                    NavigationLink("Our Menu",
                       destination: MenuView()) // Note: MenuView.swift was not provided, so Assignment 3 cannot be completed.

                    // For Assignment 2: Button to show DessertView
                    Button("View Desserts") {
                        showDesserts.toggle()
                    }

                    NavigationLink("About us",
                       destination:AboutView())
                    
                    Button("Logout") { //
                        isLoggedIn = false
                    }
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(8)
                    
                }
                .padding()
                // For Assignment 2: Sheet modifier to present DessertView
                .sheet(isPresented: $showDesserts) {
                    DessertView()
                }
            } else {
                LoginView(userName:$uName,isLoggedIn:$isLoggedIn)
            }
        }
    }
}

#Preview {
    MainView()
}
