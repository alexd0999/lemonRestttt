//
//  lemonRestApp.swift
//  lemonRest
//
//  Created by Alex Arthur on 10/23/25.
//

import SwiftUI

@main
struct lemonRestApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
