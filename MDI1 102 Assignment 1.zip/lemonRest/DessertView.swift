//
//  DessertView.swift
//  lemonRest
//
//  Created by Alex Arthur on 10/25/25.
//

import SwiftUI

struct DessertView: View {
    
    // 1. Added commas between dictionary items
    let dessertItems = [
        "Chocolate": 9.00,
        "Vanilla": 8.50,
        "Cookies": 8.80
    ]
    
    // 2. Moved `var body` outside of the dictionary
    var body: some View {
        
        // 3. Corrected the List and ForEach syntax
        // We must sort the dictionary to loop over it, as dictionaries are unordered
        List(dessertItems.sorted(by: <), id: \.key) { (name, price) in
            VStack(alignment: .leading) {
                Text(name)
                    .bold()
                Text("$ \(price, specifier: "%.2f")")
                    .foregroundColor(.secondary)
            }
        }
    }
}

#Preview {
    DessertView()
}
