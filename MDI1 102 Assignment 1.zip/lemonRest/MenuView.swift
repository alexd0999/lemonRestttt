//
//  MenuView.swift
//  lemonRest
//
//  Created by Alex Arthur on 10/23/25.
//

import SwiftUI

struct MenuView: View {
    
    // State variables for toggles
    @State private var showPremium = false
    @State private var showDessert = false
    @State private var showThankYou = false
    
    // Menu items dictionary
    let menuItems = [
        "Pizza":9.99,
        "Pasta":8.50,
        "Salad":12.20,
        "Apple":4.75,
        "Steak":15.00,
        "Lasagna": 13.50,
        "Tacos": 8.00,
        "Ramen": 6.50
    ]
    
    // Computed property for sorting (not used, but in original file)
    var sortedMenu: [(name: String, price:Double)]{
        menuItems.sorted{ $0.key > $1.key}
            .map{(key,value) in (name: key, price:value)}
    }
    
    // Computed property for filtering
    var filteredMenu: [(name: String, price:Double)]{
        menuItems.filter{ !showPremium || $0.value > 10 }
            .map{(key, value) in (name: key, price:value)}
    }
    
    // The main view body
    var body: some View {
        
        VStack{
            HStack{
                Image(systemName: "fork.knife")
                    .foregroundColor(.orange)
                    .font(.system(size: 32))
                Text("Today's menu")
                    .font(.title)
                    .bold()
            }
            
            // Extra Challenge
            Text("\(filteredMenu.count) items showing")
                .font(.caption)
                .foregroundColor(.secondary)
            
            VStack{
                Toggle("Show only premium", isOn: $showPremium)
                    .padding()
                
                if showPremium {
                    Text("You will display premium")
                        .font(.title3)
                        .foregroundColor(.green)
                }
                
                // Homework Task 1: Thank You Toggle
                Toggle("Show Thank You Message", isOn: $showThankYou)
                    .padding(.horizontal)
                
                if showThankYou {
                    Text("Thanks for visiting Little Lemon!")
                        .italic()
                        .foregroundColor(.blue)
                        .padding(.bottom)
                }
                
            }
            
            // Button to show DessertView
            Button("View Desserts"){
                showDessert.toggle()
            }
            .foregroundColor(.black)
            .padding()
            .background(Color.green.opacity(0.3))
            .cornerRadius(10)
            .sheet(isPresented:$showDessert){
                DessertView()
            }
            
            List {
                ForEach(filteredMenu, id: \.name) { (name, price) in
                    HStack {
                        VStack(alignment: .leading) {
                            Text(name)
                                .bold()
                            Text("$ \(price, specifier: "%.2f")")
                                .foregroundColor(.secondary)
                        }
                        
                        Spacer()
                        
                        // "Premium" badge
                        if price > 10 {
                            HStack {
                                Image(systemName: "star.fill")
                                Text("Premium")
                                    .font(.caption)
                            }
                            .font(.caption)
                            .foregroundColor(.orange)
                            .padding(5)
                            .background(Color.orange.opacity(0.1))
                            .cornerRadius(8)
                        }
                        
                        // Homework Task 3: Value badge
                        if price < 7 {
                            HStack {
                                Image(systemName: "dollarsign.circle.fill")
                                Text("Value")
                                    .font(.caption)
                            }
                            .font(.caption)
                            .foregroundColor(.green)
                            .padding(5)
                            .background(Color.green.opacity(0.1))
                            .cornerRadius(8)
                        }
                    }
                    .padding(.vertical, 5)
                }
            }
        }
    }
}

#Preview {
    MenuView()
}
