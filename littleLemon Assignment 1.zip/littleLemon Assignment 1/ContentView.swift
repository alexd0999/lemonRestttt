//
//  ContentView.swift
//  littleLemon Assignment 1
//
//  Created by Alex Arthur on 10/24/25.
//
import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            AboutView()
        }
    }
}
