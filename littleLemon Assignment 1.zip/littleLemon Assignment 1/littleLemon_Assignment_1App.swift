//
//  littleLemon_Assignment_1App.swift
//  littleLemon Assignment 1
//
//  Created by Alex Arthur on 10/24/25.
//

import SwiftUI

@main
struct littleLemon_Assignment_1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
