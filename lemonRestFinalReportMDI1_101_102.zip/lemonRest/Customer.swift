//
//  CustomerView.swift
//  lemonRest
//
//  Created by Alex Arthur on 01 Nov 25
//

import Foundation

struct Customer {
    var name: String
    var email: String
    var isLoyaltyMember: Bool
}
